package de.tototec.tools.cmvn;

public interface Generator {

	GeneratorResult generate();

}
